#pragma once

#define CURVE_EXPORTS
#define _USE_MATH_DEFINES

#ifdef CURVE_EXPORTS
#define CURVE_API __declspec(dllexport)
#else
#define CURVE_API __declspec(dllimport)
#endif

#include <memory>
#include <vector>
#include <math.h>

using namespace std;

enum COORDS{
	X,
	Y,
	Z,
	DX,
	DY,
	DZ,
	COUNT
};

class CURVE_API Helix
{
public:
	Helix(){}
	Helix(float, float, float);
	virtual ~Helix() {}

	virtual vector<float> C(float);

	inline float R(int r =X) { return vr[r]; }

protected:
	vector<float> vr, pt;
	void Pt(float);
};

//� ��������, ��� ������ ��� ������� ������ ������ �� �����.

class CURVE_API Circle : public Helix
{
public:
	Circle() {}
	Circle(float rx) : Helix(rx, rx, 0) {}
	virtual ~Circle() {}

	vector<float> C(float);

	inline float R() { return vr[X]; }
};

class CURVE_API Ellips : public Helix
{
public:
	Ellips(float rx, float ry) : Helix(rx, ry, 0) {}
	virtual ~Ellips() {}

	vector<float> C(float);
};


