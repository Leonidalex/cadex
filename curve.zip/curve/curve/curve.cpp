#include "pch.h"
#include "curve.h"


//Helix ------------------
Helix::Helix(float rx, float ry, float rz)
{
	pt.resize(6);
	vr.resize(3);

	vr[X] = rx;
	vr[Y] = ry;
	vr[Z] = rz;
}

void Helix::Pt(float t)
{
	pt[X] = vr[X] * cosf(t);
	pt[Y] = vr[Y] * sinf(t);
	pt[Z] = vr[Z] * t;

	pt[DX] = -pt[Y];
	pt[DY] = pt[X];
	pt[DZ] = pt[Z];
}

vector<float> Helix::C(float t)
{
	Pt(t);
	return pt;
}

//Circle ----------------------

vector<float> Circle::C(float t)
{
	Pt(t);
	vector<float> p = { pt[X], pt[Y], 0, pt[DX], pt[DY], 0 };
	return p;
}

//Ellips --------------

vector<float> Ellips::C(float t)
{
	Pt(t);
	vector<float> p = { pt[X], pt[Y], 0, pt[DX], pt[DY], 0 };
	return p;
}


