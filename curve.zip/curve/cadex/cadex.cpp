﻿#include <omp.h>
#include <iostream>
#include <conio.h>
#include <list>
#include <iterator>
#include <random>

#include <curve.h>

#define OMP_PARALLEL

typedef shared_ptr<Circle*> tSPCP;

/* ------ CTask ------ */

class CTask
{
public:
    CTask();
    CTask(int, int);

    virtual ~CTask(){ lpCirc.clear(); lCurve.clear(); }

    void Init();

    void AddCurve(); //добавить кривую
    void SortCircles(); //сортировать окружности
    void SumRadii(); //суммировать радиусы окружностей

    void PrintStatistics(){ cout << "Окружностей: " << Nc << ", " << "эллипсов: " << Ne << ", " << "спиралей: " << Nh << ".\n"; }
    void PrintSumRadii(){ cout << "Сумма радиусов окружностей: " << RadiiSum << "\n"; }
    void PrintPoints(float);

protected:
    float RadiiSum; //сумма радиусов
    int Min, Max; //диапазон изменения координат, границы для простоты целые
    list<Helix> lCurve;        //список кривых
    list<tSPCP> lpCirc;       //список указателей на кривые - окружности

private:
    std::random_device rd;
    int Rnd(int, int); //рандомайзер
    static bool CmpCirc(tSPCP, tSPCP); //ф-ция сравнения радиусов окружностей для сортироки
    int Nc, Ne, Nh; //число кривых по типам, для статистики
};

CTask::CTask()
{
    Min = 1;
    Max = 1000;

    Init();
}

CTask::CTask(int min, int max)
{
    Min = min;
    Max = max;
    
    Init();
}

void CTask::Init()
{
    RadiiSum = .0f;
    Nc = Ne = Nh = 0;
}

int CTask::Rnd(int l, int h)
{
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(l, h);
    return dist(gen);
}

bool CTask::CmpCirc(tSPCP a, tSPCP b)
{
    return (*a)->R() < (*b)->R();
}//Circ_Cmp_Fun


void CTask::AddCurve()
{
    int r = Rnd(0, 2);
    float Rx = Rnd(Min, Max);
    lCurve.push_back(Helix(Rx, r == 0 ? Rx : Rnd(Min, Max), r < 2 ? 0 : Rnd(Min, Max)));
    if (0 == r)
    {
        tSPCP picnic = make_shared<Circle*>((Circle*)&lCurve.back());
        lpCirc.push_back(picnic);

        ++Nc;
    }
    else if (1 == r)
        ++Ne;
    else
        ++Nh;
}

void CTask::SortCircles()
{
    lpCirc.sort(CmpCirc);
}

void CTask::SumRadii()
{
    float RS = 0;
#ifdef OMP_PARALLEL
    int CircN = lpCirc.size();
    list<tSPCP>::iterator it = lpCirc.begin();

#pragma omp parallel for reduction (+ : RS)
    for (int i = 0; i < CircN; ++i)
    {
        RS += (*(*it))->R();
        ++it;
    }//i
#else
    for (tSPCP cp : lpCirc)
        RadiiSum += (*cp)->R();
#endif // OMP_PARALLEL

    RadiiSum = RS;
}

void CTask::PrintPoints(float t)
{
    for (Helix curve : lCurve)
    {
        vector<float> Coo = curve.C(t);

        cout << "Параметры: rx= " << curve.R(X) << "; ry= " << curve.R(Y) << "; rz= " << curve.R(Z) << "; \n";
        cout << "Координаты точки при t= " << t << ": " << "x= " << Coo[X] << " y= " << Coo[Y] << " z= " << Coo[Z] << endl;
        cout << "Вектор производной: " << "{ " << Coo[DX] << ", " << Coo[DY] << ", " << Coo[DZ] << "}" << endl;
        cout << endl;
    }//curve
}

/* ---------- main ---------- */

int main()
{
    setlocale(LC_ALL, "ru");

    const float t = M_PI_4;
    const int CurvesN = 10;                //общее число кривых, задаём константой для простоты

    CTask Task(1, 1000); 

    for (int i = 0; i < CurvesN; ++i)
        Task.AddCurve();

    Task.PrintStatistics();
    cout << "-----------------------------------------------\n";

    Task.PrintPoints(t);
    Task.SortCircles();
    Task.SumRadii();

    Task.PrintSumRadii();

}//main

